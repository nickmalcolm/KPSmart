package gui;

import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JTextField;

public class KPSOutput extends JPanel {
	
	public KPSOutput () {
		super();
		this.setPreferredSize(new Dimension(600, 300));
	}

}

package priority;

public enum Priority {
	
	INTERNATIONAL_AIR, INTERNATIONAL_LAND, INTERNATIONAL_SEA, DOMESTIC;

}

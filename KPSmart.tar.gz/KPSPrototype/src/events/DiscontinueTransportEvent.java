package events;

public class DiscontinueTransportEvent {

}

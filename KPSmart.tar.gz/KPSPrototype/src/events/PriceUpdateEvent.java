package events;

public class PriceUpdateEvent {

}

package events;

public class Event {

}
